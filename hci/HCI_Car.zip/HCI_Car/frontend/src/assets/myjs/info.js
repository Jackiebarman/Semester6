function myfun()
{
    window.alert('YOU ARE LOGGED OUT SUCCESSFULLY!!!');
}


