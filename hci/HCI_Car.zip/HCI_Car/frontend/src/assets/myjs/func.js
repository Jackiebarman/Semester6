function fun()
{
    window.alert('Welcome to our website, Practice makes man PERFECT!!!');
}