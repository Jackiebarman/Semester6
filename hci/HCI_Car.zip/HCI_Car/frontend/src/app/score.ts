export interface score {
    username: string;
    score: number;
}