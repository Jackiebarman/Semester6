export interface history {
    username: string;
    score: number;
    DateTime: string;
}