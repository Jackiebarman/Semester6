export interface IEmployee {
    firstname: string;
    lastname: string;
    username: string;
    email: string;
    phone: number;
    address: string;
    password: string;
}


