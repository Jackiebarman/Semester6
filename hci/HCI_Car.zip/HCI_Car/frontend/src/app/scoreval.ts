export class scoreval {
    constructor(public score:string){}
}
