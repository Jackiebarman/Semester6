export class User4 {
    constructor(public username:string,public q_id:number,public res1:number,public res2:number,public res3:number){}
}