export class Comments
{
    name: string;
    age: number;
    roll: number;
}