export class User2 {
    constructor(public firstname:string,public lastname:string,public username:string,public email:string,public phone:number,public address:string,public password:string,public confirmpassword:string,public score:number){}
}
