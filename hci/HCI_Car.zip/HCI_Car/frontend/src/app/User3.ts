export class User3 {
    constructor(public username:string,public password:string,public score:number,public date:string){}
}