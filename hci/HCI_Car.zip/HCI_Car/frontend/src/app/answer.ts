export interface answer {
    set_ID: number;
    q_no: number;
    answer: number
}