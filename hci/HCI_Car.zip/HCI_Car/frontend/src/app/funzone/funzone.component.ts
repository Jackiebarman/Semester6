import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-funzone',
  templateUrl: './funzone.component.html',
  styleUrls: ['./funzone.component.css']
})
export class FunzoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
